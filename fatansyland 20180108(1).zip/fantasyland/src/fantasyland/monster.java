/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fantasyland;

/**
 *
 * @author DELL
 */
public class monster extends character{
	double dropPossibility;
	//nP是dropPossibility,怪物的掉落几率
        Human tempForMan;
        //这个变量用来储存角色Man的数据，见下面的tempForMan函,int nspeed,int nexp,int nP数
	public monster(int nx,int ny,double nP){
		super(1200,4000,nx,ny,1,120);
                //所有怪物的初始攻击力都是1200，血量3000,移动速度1格，掉落经验120
		this.dropPossibility=nP;
                //怪物掉落几率因怪物种类而异
	}
        
        public void SetTempForMan(Human human1){
            Human tempForMan=human1;
        }
        //战斗开始时，这个函数用来储存角色human1的数据，以便怪物被human1打死后，去掉human1身上的Debuff，恢复其原来的atk、exp和speed
	public void NoDebuff(Human human1){
            if(this.getHp()<=0){
                human1=tempForMan;
            }
        }
        //怪物死后，这个函数用来消除角色human1身上的debuff；消除完了之后，再调用其它函数，给予角色human1经验、装备等奖励
	
	public void dropEqu(Human human1) {
		//Before coding the equipment class, I will not code this fucntion
	}
        
        public void dropExp(Human human1) {
            human1.setExp(human1.getExp()+this.getExp());
	}
        //该函数表示掉落经验函数（怪物被杀之后调用）：ah角色增长的经验值=ah原经验值+该角色经验值
}
