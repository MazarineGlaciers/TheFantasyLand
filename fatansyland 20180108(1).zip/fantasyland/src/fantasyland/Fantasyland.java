/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fantasyland;
import java.util.*;
/**
 *
 * @author DELL
 */
public class Fantasyland {
public static void chooseocc(int c, String Occupation) {

        //choose occupation选择职业函数
        //选择变量
        if (c == 1) {
            Occupation = "Assassin";

        }
        if (c == 2) {
            Occupation = "Tank";

        }
        if (c == 3) {
            Occupation = "Magician";

        }
        if (c == 4) {
            Occupation = "Warrior";

        }

        System.out.println("Occupation:" + Occupation);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        System.out.println("choose your occupation");
        System.out.println("1=Assassin" + " " + "2=Tank" + " " + "3=Magician" + " " + "4=Warrior");
        Scanner sc = new Scanner(System.in);
        int temp1 = 999999;//输入选择数
        for (int i = 0; i < 999999; i++) {
            temp1 = sc.nextInt();
            if (temp1 > 0 && temp1 < 5) {
                break;
            }
            if(temp1<=0||temp1>=5){
                System.out.println("False Occ,choose again");
            }
        }

        chooseocc(temp1, "");

    }
}
